import os
import concurrent.futures
from utils import plot_msg

def plot_all_bands(data_dir, output_path, date_arg, time_arg, fnames, band):
    _output_path = output_path.replace('**band_name**', band)
    if not os.path.exists(_output_path):
        plot_msg(data_dir, _output_path, band, fnames)

def plot_all_bands_parallel(data_dir, output_path, date_arg, time_arg, fnames):
    bands = [
        'HRV',
        'IR_016',
        'IR_039',
        'IR_087',
        'IR_097',
        'IR_108',
        'IR_120',
        'IR_134',
        'VIS006',
        'VIS008',
        'WV_062',
        'WV_073',
    ]
    # Use ThreadPoolExecutor to create a pool of threads
    with concurrent.futures.ThreadPoolExecutor() as executor:
        # Submit each band processing as a separate thread
        futures = [executor.submit(plot_all_bands, data_dir, output_path, date_arg, time_arg, fnames, band) for band in bands]
        # Wait for all threads to complete
        concurrent.futures.wait(futures)
    
export = plot_all_bands_parallel
