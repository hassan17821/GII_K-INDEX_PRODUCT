import os
import sys

# Import functions from modules
from fog import plot_fog
from all_bands import plot_all_bands,plot_all_bands_parallel
from all_products import plot_products
from satpy.utils import debug_off,debug_on
debug_off()
import warnings
warnings.filterwarnings('ignore')

# debug_on()
if len(sys.argv) == 5:
    # Extract command-line arguments
    date_arg, time_arg, input_path_arg, output_path_arg = sys.argv[1:]
    output_data = [
        # {
        #     'output_path': f'{output_path_arg}/fog [{time_arg}].webp',
        #     'function': plot_fog
        # },
        {
            'output_path': f'{output_path_arg}/**band_name** [{time_arg}].webp',
            'function': plot_all_bands_parallel
        },
        {
            'output_path': f'{output_path_arg}/**product_name** [{time_arg}].webp',
            'function': plot_products
        }
    ]

    files = os.listdir(input_path_arg)
    fnames = [os.path.join(input_path_arg, f) for f in files]
    print("FileNames Length :: ", len(fnames))
    if len(fnames) < 140:
        print("Insufficient number of files in the directory. Expected at least 140 files.")
    else:
        print("input_path_arg :: ",input_path_arg)
        for item in output_data:
            output_path = item['output_path']
            function = item['function']
            if not os.path.exists(output_path):
                function(input_path_arg, output_path, date_arg, time_arg,fnames)

else:
    print("Some required arguments are missing.")
